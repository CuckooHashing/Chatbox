#include "ChatSession.h"



ChatSession::ChatSession()
{
}


ChatSession::~ChatSession()
{
}
